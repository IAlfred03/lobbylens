from fastapi import FastAPI
from api import aggregation, comparison, dashboard, filters

app = FastAPI()

app.include_router(aggregation.router)
app.include_router(comparison.router)
app.include_router(dashboard.router)
app.include_router(filters.router)
